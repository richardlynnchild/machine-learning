#!/bin/bash
python3 problem2a.py
python3 problem2b.py
python3 problem2c.py 
