*** To execute scripts simply type ./run.sh ***

Author: Richard Child  u0581030
Date: March 8, 2019
University of Utah CS 5350
Homework 3 - Perceptron

This directory contains implementations for the following algorithms:

Standard Perceptron
Voted Perceptron
Average Perceptron

All of the implementations are located in Perceptron.py

For the homework, three scripts have been written to answer questions in
Part 2 Problem 2 (parts a, b, and c).

These scripts can all be run using the run.sh file.
To execute simply type ./run.sh in the terminal.
