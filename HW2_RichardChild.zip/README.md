# machine-learning
This is a machine learning library developed by Richard Child for CS5350 in the University of Utah.

## Decision Trees
DecisionTree.py contains the implementation of the ID3 algorithm used to create 
the data structure. Calling the function "ID3" will return the root node of
the decision tree.