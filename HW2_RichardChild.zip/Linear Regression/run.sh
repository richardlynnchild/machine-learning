#!/bin/bash
python3 concrete_4a.py