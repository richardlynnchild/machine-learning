#!/bin/bash
python3 bank_1a.py