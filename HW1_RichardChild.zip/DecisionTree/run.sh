#!/bin/bash
python3 car.py
python3 bank_3a.py  
python3 bank_3b.py  
