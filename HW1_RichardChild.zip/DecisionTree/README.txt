CS 5350
Homework 1 - Decision Trees
Author: Richard Child
Date: February 13, 2019

**** type ./run.sh to run this homework script ****

In this directory you will find the written solutions in the file titled: homework1.pdf

The ID3 algorithm is implemented in the DecisionTree.py file (Node.py is a helper class).
Question 2 is solved using car.py
Question 3a is solved using bank_3a.py
Question 3b is solved using bank_3b.py
The results of the error prediction calculations are stored in three separate .csv files.

Shell script run.sh is provided to run these scripts and produce .csv files.